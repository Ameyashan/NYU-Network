# NYU-Network: A University Social Network

A University Social Network prototype developed using MySQL, PHP, HTML, CSS and JavaScript.

<b>Features</b>: sending friend requests, creating posts, likes, dislikes, updating user profile, viewing activity feed
